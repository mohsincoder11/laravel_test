<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Login_detail extends Model
{
    //
}
