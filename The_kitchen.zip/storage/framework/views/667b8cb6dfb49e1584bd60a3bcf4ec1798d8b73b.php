<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('public/assets/assets/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/assets/fonts/bootstrap-font/bootstrap-icons.css')); ?>" rel="stylesheet">

    
    <?php echo $__env->yieldContent('css'); ?>
    <title>The Kitchen!</title>

    <style>

    </style>
</head>

<body>

   <?php echo $__env->yieldContent('content'); ?>
    <!-- ===== Bootstrap Bundle with Popper ===== -->
    <script type="text/javascript" src="<?php echo e(asset('public/assets/assets/jquery/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/assets/bootstrap/js/bootstrap.bundle.js')); ?>"></script>
    <!-- owl carousel -->
   

   <?php echo $__env->yieldContent('js'); ?>


</body>

</html><?php /**PATH C:\wamp64\www\The_Kitchen\resources\views/layout.blade.php ENDPATH**/ ?>